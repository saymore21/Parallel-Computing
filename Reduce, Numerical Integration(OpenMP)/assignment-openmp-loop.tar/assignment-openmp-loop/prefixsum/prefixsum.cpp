#include <omp.h>
#include <stdio.h>
#include <iostream>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <chrono>


using namespace std;
using seconds = chrono::seconds;
using check_time = std::chrono::high_resolution_clock;


#ifdef __cplusplus
extern "C" {
#endif
  void generatePrefixSumData (int* arr, size_t n);
  void checkPrefixSumResult (int* arr, size_t n);
#ifdef __cplusplus
}
#endif


int main (int argc, char* argv[]) {
  //forces openmp to create the threads beforehand
#pragma omp parallel
  {
    int fd = open (argv[0], O_RDONLY);
    if (fd != -1) {
      close (fd);
    }
    else {
      std::cerr<<"something is a miss"<<std::endl;
    }
  }
  
  if (argc < 3) {
    std::cerr<<"Usage: "<<argv[0]<<" <n> <nbthreads>"<<std::endl;
    return -1;
  }

  //Starting the clock time
  auto initiated = check_time::now();

  // Reading the array size input
  int n = atoi(argv[1]);

  int * arr = new int [n];
  generatePrefixSumData (arr, n); // THis function generates an array for prefix sum

  // Prefix sum array initialization
  int * pr = new int [n+1];
  //Assigning the first index position value as zero according to prefix logic
  pr[0]= 0;

  //Calculating prefix sum
  for(int i = 1; i <= n; i+=2)
  {
   pr[i] = arr[i-1];
   if(i != (n+1))
  {  
   pr[i+1] = arr[i] + pr[i];
  }
  }
   
   for(int i = 3; i <= n; i+=2)
   {
   int j = i-1;
   int prevsum = 0;
   while(j>1)
   {
   prevsum += pr[j];
   j= j-2;
   }  
   pr[i] = pr[i] + prevsum;
   if(i != (n+1))
   {
   pr[i+1] = prevsum + pr[i+1];
   }
   }
  
  //Cross checks if the prefix result is correct
  checkPrefixSumResult(pr, n);
  delete[] arr;

  auto end = check_time::now();
  auto time_elapsed = end - initiated;
  auto secs = std::chrono::duration_cast<std::chrono::duration<float>>(time_elapsed);

  std::cerr<< "The time required was: " << secs.count();

  return 0;
}
