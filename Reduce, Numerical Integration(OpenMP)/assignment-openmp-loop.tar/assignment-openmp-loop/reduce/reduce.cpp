#include <omp.h>
#include <stdio.h>
#include <iostream>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <chrono>
#include <string.h>


using namespace std;
using seconds = chrono::seconds;
using check_time = std::chrono::high_resolution_clock;

#ifdef __cplusplus
extern "C" {
#endif
  void generateReduceData (int* arr, size_t n);
#ifdef __cplusplus
}
#endif


int main (int argc, char* argv[]) {
  //forces openmp to create the threads beforehand
    #pragma omp parallel
   {
    int fd = open (argv[0], O_RDONLY);
    if (fd != -1) {
      close (fd);
    }
    else {
      std::cerr<<"something is a miss"<<std::endl;
    }
    
 }
  
  if (argc < 5) {
    std::cerr<<"Usage: "<<argv[0]<<" <n> <nbthreads> <scheduling> <granularity>"<<std::endl;
    return -1;
  }

  //Starting the clock time
  auto initiated = check_time::now();

  //Assigneing all the inputs to the correspoding variables.
  int n = atoi(argv[1]);
  int * arr = new int [n];
  int nbthreads = atoi(argv[2]);
  int granularity = atoi(argv[4]);
  int result_sum = 0; //variable to store final result


  //Setting or requesting the number of threads to openmp  
  omp_set_num_threads(nbthreads);
 
  generateReduceData (arr, atoi(argv[1]));

  //Setting scheduling type
  if(argv[3] == "static")
 {
  omp_set_schedule(omp_sched_static,granularity);
 }
 else if (argv[3] == "dynamic")
 {
  omp_set_schedule(omp_sched_dynamic,granularity);
 }
 else if (argv[3] == "guided")
 {
  omp_set_schedule(omp_sched_guided,granularity);
 }
//insert reduction code here
 // #pragma omp parallel
  //#pragma omp for schedule(runtime)
  #pragma omp parallel for reduction(+:result_sum)
  for(int i = 0; i < n;  i++)
 {
  result_sum += arr[i];
 }  


  delete[] arr;
  
  std::cout << result_sum; //Printing the result sum
  auto end = check_time::now();
  auto time_elapsed = end - initiated;
  auto secs = std::chrono::duration_cast<std::chrono::duration<float>>(time_elapsed);

  std::cerr<<secs.count();

  return 0;
}
