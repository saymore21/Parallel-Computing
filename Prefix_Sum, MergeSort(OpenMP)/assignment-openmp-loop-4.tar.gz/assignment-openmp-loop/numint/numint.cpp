#include <omp.h>
#include <stdio.h>
#include <iostream>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <cstdlib>
#include <chrono>

using namespace std;
using seconds = chrono::seconds;
using check_time = std::chrono::high_resolution_clock;

#ifdef __cplusplus
extern "C" {
#endif

float f1(float x, int intensity);
float f2(float x, int intensity);
float f3(float x, int intensity);
float f4(float x, int intensity);

#ifdef __cplusplus
}
#endif



int main (int argc, char* argv[]) {

   //starting clock time
   auto initiated = check_time::now();
  //forces openmp to create the threads beforehand
   #pragma omp parallel
   {
    int fd = open (argv[0], O_RDONLY);
    if (fd != -1) {
      close (fd);
    }
    else {
      std::cerr<<"something is amiss"<<std::endl;
    }
    }
  
  if (argc < 9) {
    std::cerr<<"Usage: "<<argv[0]<<" <functionid> <a> <b> <n> <intensity> <nbthreads> <scheduling> <granularity>"<<std::endl;
    return -1;
  }

	//Taking inputs for the function into corresponding variables
	int i=0;
	int _id = stoi(argv[1]);	
	float val = 0; //total sum
        float a = stof(argv[2]);
	float b = stof(argv[3]);
	int n= stoi(argv[4]);
	int intensity = stoi(argv[5]);
	float range = (b-a)/n; //Constant part calculated to be passed to the functions for integrations
	int nbthreads = stoi(argv[6]); //Number of threads
	int granularity = stoi(argv[8]);
	
	//Set or request number of threads to be used to Openmp
	omp_set_num_threads(nbthreads);

	
	if(argv[7] == "static")
 	{
	 //Setting Schedule as Static 
  	  omp_set_schedule(omp_sched_static,granularity);
 	}
 	else if (argv[7] == "dynamic")
 	{
	   //Setting Schedule as Dynamic 
  	   omp_set_schedule(omp_sched_dynamic,granularity);
	} 
	else if (argv[7] == "guided")
 	{
	   //Setting Schedule as Dynamic 
  	   omp_set_schedule(omp_sched_guided,granularity);
	} 	
	

	if (_id == 1)
		{
			#pragma omp parallel for reduction(+:val) schedule(runtime)
			for(i=0; i<=n-1; i++)
				{
					float firstparam = a+(i+0.5)*(range);	
					val += f1(firstparam, intensity);
				}
		}	
	else if (_id == 2)
		{
			#pragma omp parallel for reduction(+:val) schedule(runtime)
			for(i=0; i<=n-1; i++)
				{
					float firstparam = a+(i+0.5)*(range);	
					val += f2(firstparam, intensity);
				}
		}
	else if (_id == 3)
		{
			#pragma omp parallel for reduction(+:val) schedule(runtime)
			for(i=0; i<=n-1; i++)
				{
					float firstparam = a+(i+0.5)*(range);	
					val += f3(firstparam, intensity);
				}
		}
	else if (_id == 4)
		{
			#pragma omp parallel for reduction(+:val) schedule(runtime)
		 	for(i=0; i<=n-1; i++)
				{
					float firstparam = a+(i+0.5)*(range);	
					val += f4(firstparam, intensity);
				}
		}

 	val = val*range;

	//Output Numerical Integration
	cout<<val;
	//stopping th clocktime
	auto end = check_time::now();
	auto time_elapsed = end - initiated;
	auto secs = std::chrono::duration_cast<std::chrono::duration<float>>(time_elapsed);

	//Output time elapsed
	cerr<<secs.count();

  return 0;
}
