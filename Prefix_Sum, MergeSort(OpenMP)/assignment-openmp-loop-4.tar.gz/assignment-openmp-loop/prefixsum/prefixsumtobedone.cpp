#include <omp.h>
#include <stdio.h>
#include <iostream>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <chrono>
#include <array>

using namespace std;
using seconds = chrono::seconds;
using check_time = std::chrono::high_resolution_clock;


#ifdef __cplusplus
extern "C" {
#endif
  void generatePrefixSumData (int* arr, size_t n);
  void checkPrefixSumResult (int* arr, size_t n);
#ifdef __cplusplus
}
#endif


int main (int argc, char* argv[]) {
  //forces openmp to create the threads beforehand
#pragma omp parallel
  {
    int fd = open (argv[0], O_RDONLY);
    if (fd != -1) {
      close (fd);
    }
    else {
      std::cerr<<"something is a miss"<<std::endl;
    }
  }
  
  if (argc < 3) {
    std::cerr<<"Usage: "<<argv[0]<<" <n> <nbthreads>"<<std::endl;
    return -1;
  }

  //Starting the clock time
  auto initiated = check_time::now();

  // Reading the array size input
  int n = atoi(argv[1]);
  int nbthreads = atoi(argv[2]); //Number of threads
  int * arr = new int [n];
  int thread_limit = 0;
  
  generatePrefixSumData (arr, n); // THis function generates an array for prefix sum
  
  //Set or request number of threads to be used to Openmp
  omp_set_num_threads(nbthreads);

  // Prefix sum array initialization
  int * pr = new int [n+1];
  //int * temp = new int [(n/2)];
  //int granularity = n/nbthreads;
  //Assigning the first index position value as zero according to prefix logic
  pr[0]= 0;
   if((n%nbthreads)== 0)
  { 
   thread_limit = nbthreads;
  }
  else if((n%nbthreads)<=(n/nbthreads))
{
  thread_limit  = nbthreads + 1;
}
 else if((n%nbthreads)>(n/nbthreads))
{
  thread_limit  = nbthreads + 2;
}
 //std::cout << "thread_limit" << thread_limit << "\n";

/*  std::cout <<"Start main" << "\n";
  for(int i = 0; i <n; i++)
  {
   std::cout << arr[i] << "\n";
   }

 std::cout <<"End" << "\n";*/

  #pragma omp parallel for schedule (static)
  for(int j = 0; j< thread_limit; j++)
  {
  //std::cout << "we are first for " << "\n";
int count = 0;
  //Calculating prefix sum
  for(int i = (n/nbthreads)*j; i < (n/nbthreads)*(j+1); i++)
  {

/// std::cout << "we are in second for " << "\n";
    if(count == 0)
    {
	pr[i+1] = arr[i];
        count++;
     }
     else
        pr[i+1] = arr[i] + pr[i];
  //std::cout << "pr[" << (i+1) << "] " << pr[i+1] << "\n";
    }
   }


/*std::cout <<"Beech main" << "\n";
  for(int i = 0; i <= n; i++)
  {
   std::cout << pr[i] << "\n";
   }*/
//#pragma omp parallel for schedule (static)


  for(int t = 0; t<= (n); t+= (n/nbthreads))
  { 
     int index = (n/nbthreads)+(2*t);
     int adjust = pr[index];
    //  std::cout << "adjust " << adjust << "\n";
     for(int j= index; j < (index + (n/nbthreads)); j++)
	{
	   pr[j+1] += adjust;
         //  std::cout << "pr[" << (j+1) << "]" << pr[j+1] << "\n";
        }
   }

/*if(nbthreads>1)
{
//std::cout<<"I am in " <<"\n";
int adjust = pr[(n/nbthreads)];
std::cout <<"Adjust" << adjust <<"\n";
for(int i = (n/nbthreads)+1; i <= ((n/nbthreads)*2); i+=(n/nbthreads))
{ 
 pr[i] += adjust;
}
}*/
/*std::cout <<"The array manipulated" << "\n";
  for(int i = 0; i <= n; i++)
  {
   std::cout << pr[i] << "\n";
}
  //temp[0] = 0;

 /* for (int j = 0; j <= sizeof(temp) ; j++)
  {
	index = index+2;
        temp[j+1] = temp[j] + pr[index];
  } */
	
//  index = 1;
 
 /* for (int i = 1; i<= n; i+=2)
  {
	pr[i] += temp[index];
	pr[i+1] += temp[index];
	index++;
  }*/
	
   
  //Cross checks if the prefix result is correct
  checkPrefixSumResult(pr, n);
  delete[] arr;

  auto end = check_time::now();
  auto time_elapsed = end - initiated;
  auto secs = std::chrono::duration_cast<std::chrono::duration<float>>(time_elapsed);

  std::cerr<< secs.count();

  return 0;
}
