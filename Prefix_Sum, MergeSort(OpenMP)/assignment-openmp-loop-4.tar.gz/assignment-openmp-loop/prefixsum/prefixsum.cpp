#include <omp.h>
#include <stdio.h>
#include <iostream>
#include <fcntl.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/stat.h>
#include <chrono>

using namespace std;
using seconds = chrono::seconds;
using check_time = std::chrono::high_resolution_clock;

#ifdef __cplusplus
extern "C" {
#endif
  void generatePrefixSumData (int* arr, size_t n);
  void checkPrefixSumResult (int* arr, size_t n);
#ifdef __cplusplus
}
#endif


int main (int argc, char* argv[]) {

  //Starting the clock time
  auto initiated = check_time::now();

  
  if (argc < 3) {
    std::cerr<<"Usage: "<<argv[0]<<" <n> <nbthreads>"<<std::endl;
    return -1;
  }

  
  int n = atoi(argv[1]);

  int * arr = new int [n];
  int * pr = new int [n+1];
  generatePrefixSumData (arr, n);
  int nbthreads = atoi(argv[2]);
  int chunk = n/nbthreads;

  int * middle = new int [nbthreads];
  int * index_arr = new int [nbthreads];

 
  middle[0] = 0;
  index_arr[0] = 0;
  
  omp_set_num_threads(nbthreads);


#pragma omp parallel
  {
    int fd = open (argv[0], O_RDONLY);
    if (fd != -1) {
      close (fd);
    }
    else {
      std::cerr<<"something is amiss"<<std::endl;
    }

   pr[0] = 0;

  #pragma omp for schedule(static)
  for(int j = 0; j < nbthreads; j++)
   {
    for(int i= j*chunk;i<(j+1)*chunk; i++)
     {
      if(i== (j * chunk))
     {
        pr[i+1] = 0 + arr[i];
      }
      else
      {
        pr[i+1] = pr[i] + arr[i];
      }
      middle[j+ 1] = pr[i+1];  
     }
      index_arr[j +1] = ((j +1) * chunk)+1;
  }
}

    if(nbthreads * chunk < n)
    {
        for(int i = chunk * nbthreads; i < n; i++)
      {
          pr[i+1] = pr[i] + arr[i];
        }
      }


  int * left_sum = new int [nbthreads];
left_sum[0] = middle[0];
  for(int i = 1; i<nbthreads; i++)
  {
    left_sum[i] = left_sum[i-1] + middle[i];
  }


#pragma omp parallel for schedule(dynamic)
  for(int i =0;i<nbthreads; i++)
  {
    for(int j=index_arr[i]; j < index_arr[i+1]; j++)
  {
    pr[j] = pr[j] + left_sum[i];
    }


  }


      if(chunk * nbthreads < n)
     {
        for(int j = nbthreads * chunk; j < n; j++)
       {
          pr[j+1] = pr[j+1] + left_sum[nbthreads-1];
        }
      }
  


  checkPrefixSumResult(pr, n);

  delete[] arr;

  //stopping the clock 
  auto end = check_time::now();
  auto time_elapsed = end - initiated; // calculating the time required
  auto secs = std::chrono::duration_cast<std::chrono::duration<float>>(time_elapsed);

  std::cerr<< secs.count();

  return 0;
}