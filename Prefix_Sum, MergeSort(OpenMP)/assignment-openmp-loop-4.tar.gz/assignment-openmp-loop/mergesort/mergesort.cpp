#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <iostream>
#include <unistd.h>
#include <chrono>

using namespace std;
#ifdef __cplusplus
extern "C" {
#endif
  void generateMergeSortData (int* arr, size_t n);
  void checkMergeSortResult (int* arr, size_t n);
#ifdef __cplusplus
}
#endif
/*
*/
int main (int argc, char* argv[]) {
auto start = chrono::steady_clock::now();
  //forces openmp to create the threads beforehand
#pragma omp parallel
  {
    int fd = open (argv[0], O_RDONLY);
    if (fd != -1) {
      close (fd);
    }
    else {
      std::cerr<<"something is amiss"<<std::endl;
    }
  }
 
  if (argc < 3) { std::cerr<<"Usage: "<<argv[0]<<" <n> <nbthreads>"<<std::endl;
    return -1;
  }

  int n = atoi(argv[1]);
  int nbthreads = atoi(argv[2]);
 
  // get arr data
  int * arr = new int [n];
int * temparr = new int [n];
  generateMergeSortData (arr, n);

 int right,end;
  int s,d,mid,t;
  int a = 0; 
#pragma omp parallel
  {
    int fd = open (argv[0], O_RDONLY);
    if (fd != -1) {
      close (fd);
    }
    else {
      std::cerr<<"something is amiss"<<std::endl;
    }
  
#pragma omp for reduction(*:a) schedule(static, 1)

     for(int t = 0; t <nbthreads; t++){
while(a<n){     
        for (int left=0; left+a < n; left += a*2 ) {
            right = left + a;       
            end = right + a;
            if (end > n) end = n;
            mid = left; s = left; d = right;
            while (s < right && d < end) {
                if (arr[s] <= arr[d]) {        
                    temparr[mid] = arr[s]; s++;
                } else {
                    temparr[mid] = arr[d]; d++;
                }
                mid++;
            }
            while (s < right) {
                temparr[mid]=arr[s];
                s++; mid++;
            }
            while (d < end) {
                temparr[mid]=arr[d];
                d++; mid++;
            }
            for (mid=left; mid < end; mid++) {
                arr[mid] = temparr[mid];
            }
        }

   a = a * 2;
}
   
    }
}
 
  checkMergeSortResult (arr, n);
 
  delete[] arr;
  // end time
  auto timeend = chrono::steady_clock::now();
  std::chrono::duration<double> elapsed = timeend - start;
  cerr<<elapsed.count();
  return 0;
}

